# Build DeviceLab X APK from iPhone

1. Create a new GitHub repository.
2. Upload the contents of this project to the repository.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build DeviceLab X APK**.
6. Press **Run workflow** if it did not start automatically.
7. Open the completed workflow run.
8. Under **Artifacts**, download `DeviceLab-X-debug-apk`.
9. The downloaded artifact contains `app-debug.apk`.

The workflow builds a debug APK. For a Play Store release, create a properly signed release build later.
