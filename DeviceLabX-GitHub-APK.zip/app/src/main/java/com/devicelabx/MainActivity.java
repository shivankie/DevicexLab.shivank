package com.devicelabx;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    LinearLayout root, content;
    int white = Color.rgb(247,247,251);
    int muted = Color.rgb(142,148,167);
    int panel = Color.rgb(16,18,26);
    int accent = Color.rgb(139,92,246);
    int green = Color.rgb(52,211,153);
    int yellow = Color.rgb(251,191,36);
    int red = Color.rgb(251,113,133);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildShell();
        showDashboard();
    }

    TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, 0, 0, 8);
        return t;
    }

    TextView title(String s) {
        TextView t = tv(s, 22, white);
        t.setTypeface(null, 1);
        t.setPadding(0, 18, 0, 12);
        return t;
    }

    TextView cardText(String s) {
        TextView t = tv(s, 15, white);
        t.setPadding(18, 15, 18, 15);
        t.setBackgroundColor(panel);
        return t;
    }

    void buildShell() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 16, 20, 28);
        root.setBackgroundColor(Color.rgb(7,8,13));
        scroll.addView(root);
        setContentView(scroll);
    }

    void baseHeader(String sub) {
        root.removeAllViews();
        TextView brand = tv("DEVICELAB X", 28, white);
        brand.setTypeface(null, 1);
        root.addView(brand);
        TextView small = tv(sub, 13, muted);
        root.addView(small);
        Space sp = new Space(this);
        root.addView(sp, new LinearLayout.LayoutParams(1, 10));
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(white);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(28,30,43));
        b.setPadding(14, 8, 14, 8);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 54);
        p.setMargins(0, 7, 0, 7);
        b.setLayoutParams(p);
        return b;
    }

    void showDashboard() {
        baseHeader("Android Security & Device Intelligence");

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(20,20,20,20);
        hero.setBackgroundColor(panel);
        TextView h = tv("Your device", 15, muted);
        hero.addView(h);
        TextView model = tv(Build.MANUFACTURER + " " + Build.MODEL, 24, white);
        model.setTypeface(null,1); hero.addView(model);
        hero.addView(tv("Android " + Build.VERSION.RELEASE + "  •  API " + Build.VERSION.SDK_INT, 14, muted));
        root.addView(hero);

        root.addView(title("Security overview"));
        TextView status = cardText("●  READY TO SCAN\n\nRun DeviceLab's non-destructive checks to analyze root indicators, debugging state, SELinux, build configuration and other available signals.");
        root.addView(status);

        root.addView(title("Modules"));
        Button scan = btn("🛡  ROOT / SECURITY SCAN");
        scan.setOnClickListener(v -> showSecurity());
        root.addView(scan);

        Button info = btn("📱  DEVICE INFORMATION");
        info.setOnClickListener(v -> showDevice());
        root.addView(info);

        Button performance = btn("⚡  PERFORMANCE SNAPSHOT");
        performance.setOnClickListener(v -> showPerformance());
        root.addView(performance);

        root.addView(title("DeviceLab X"));
        root.addView(cardText("v1.0 • Diagnostic build\n\nThe scanner reports observable indicators. It does not modify the device or bypass security controls."));
    }

    void showDevice() {
        baseHeader("Device Information");
        root.addView(title("Identity"));
        root.addView(cardText(
            "Manufacturer     " + Build.MANUFACTURER + "\n" +
            "Brand            " + Build.BRAND + "\n" +
            "Model            " + Build.MODEL + "\n" +
            "Device           " + Build.DEVICE + "\n" +
            "Product          " + Build.PRODUCT + "\n" +
            "Board            " + Build.BOARD
        ));

        root.addView(title("Android"));
        root.addView(cardText(
            "Version          Android " + Build.VERSION.RELEASE + "\n" +
            "API Level        " + Build.VERSION.SDK_INT + "\n" +
            "Security Patch   " + (Build.VERSION.SDK_INT >= 23 ? Build.VERSION.SECURITY_PATCH : "N/A") + "\n" +
            "Build ID         " + Build.ID + "\n" +
            "Fingerprint      " + Build.FINGERPRINT
        ));

        root.addView(title("Memory & Storage"));
        root.addView(cardText(
            "RAM              " + ramGB() + "\n" +
            "Storage Total    " + storageTotal() + "\n" +
            "Storage Free     " + storageFree()
        ));

        root.addView(title("Display"));
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        root.addView(cardText(
            "Resolution       " + dm.widthPixels + " × " + dm.heightPixels + "\n" +
            "Density          " + dm.densityDpi + " dpi"
        ));

        Button back = btn("←  Dashboard");
        back.setOnClickListener(v -> showDashboard());
        root.addView(back);
    }

    String ramGB() {
        android.app.ActivityManager am = (android.app.ActivityManager)getSystemService(ACTIVITY_SERVICE);
        android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return String.format("%.1f GB", mi.totalMem / 1073741824.0);
    }

    String storageTotal() {
        StatFs s = new StatFs(Environment.getDataDirectory().getPath());
        return String.format("%.1f GB", s.getTotalBytes()/1073741824.0);
    }

    String storageFree() {
        StatFs s = new StatFs(Environment.getDataDirectory().getPath());
        return String.format("%.1f GB", s.getAvailableBytes()/1073741824.0);
    }

    boolean hasSuBinary() {
        String[] paths = {"/system/bin/su","/system/xbin/su","/sbin/su","/vendor/bin/su","/data/local/su","/data/local/bin/su"};
        for (String p: paths) if (new File(p).exists()) return true;
        return false;
    }

    boolean testKeys() {
        String tags = Build.TAGS;
        return tags != null && tags.contains("test-keys");
    }

    boolean debuggableBuild() {
        return (Build.TYPE != null && Build.TYPE.equals("eng")) ||
               (Build.TYPE != null && Build.TYPE.equals("userdebug"));
    }

    boolean selinuxEnforcing() {
        try {
            Class<?> c = Class.forName("android.os.SELinux");
            java.lang.reflect.Method m = c.getMethod("isSELinuxEnforced");
            return (Boolean)m.invoke(null);
        } catch (Exception e) { return true; }
    }

    boolean developerOptions() {
        try {
            return Settings.Global.getInt(getContentResolver(),
                    Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
        } catch (Exception e) { return false; }
    }

    boolean adbEnabled() {
        try {
            return Settings.Global.getInt(getContentResolver(),
                    Settings.Global.ADB_ENABLED, 0) == 1;
        } catch (Exception e) { return false; }
    }

    void showSecurity() {
        baseHeader("Root & Security Scanner");
        root.addView(title("Deep scan"));

        boolean su = hasSuBinary();
        boolean test = testKeys();
        boolean debug = debuggableBuild();
        boolean selinux = selinuxEnforcing();
        boolean dev = developerOptions();
        boolean adb = adbEnabled();

        int risk = 0;
        if (su) risk += 45;
        if (test) risk += 25;
        if (debug) risk += 15;
        if (!selinux) risk += 15;
        if (adb) risk += 5;
        if (risk > 100) risk = 100;

        String verdict;
        int vc;
        if (risk <= 20) { verdict = "LOW RISK"; vc = green; }
        else if (risk <= 50) { verdict = "ATTENTION"; vc = yellow; }
        else { verdict = "HIGH RISK"; vc = red; }

        TextView score = cardText("SECURITY RISK SCORE\n\n" + risk + " / 100\n\n" + verdict);
        score.setTextColor(vc);
        root.addView(score);

        root.addView(title("Root indicators"));
        root.addView(cardText(
            row("su binary", su ? "⚠ FOUND" : "✓ NOT FOUND", su) +
            row("Build tags", test ? "⚠ TEST-KEYS" : "✓ NORMAL", test) +
            row("Build type", debug ? "⚠ " + Build.TYPE : "✓ " + Build.TYPE, debug)
        ));

        root.addView(title("System security"));
        root.addView(cardText(
            row("SELinux", selinux ? "✓ ENFORCING" : "⚠ NOT ENFORCING", !selinux) +
            row("Developer options", dev ? "⚠ ENABLED" : "✓ DISABLED", dev) +
            row("USB debugging", adb ? "⚠ ENABLED" : "✓ DISABLED", adb)
        ));

        root.addView(title("Anti-evasion analysis"));
        root.addView(cardText(
            "This module compares independent observable signals.\n\n" +
            "Direct root result: " + (su ? "DETECTED" : "NOT DETECTED") + "\n" +
            "Modification indicators: " + ((test || debug) ? "PRESENT" : "NONE FOUND") + "\n" +
            "Environment consistency: " + ((test || debug || !selinux) ? "REVIEW" : "NORMAL") + "\n\n" +
            "Note: sophisticated root-hiding or tampering cannot be guaranteed to be detected by a normal app."
        ));

        Button rescan = btn("↻  SCAN AGAIN");
        rescan.setOnClickListener(v -> showSecurity());
        root.addView(rescan);

        Button back = btn("←  Dashboard");
        back.setOnClickListener(v -> showDashboard());
        root.addView(back);
    }

    String row(String a, String b, boolean warning) {
        return a + "   " + b + "\n";
    }

    void showPerformance() {
        baseHeader("Performance Snapshot");
        root.addView(title("Hardware snapshot"));
        root.addView(cardText(
            "CPU ABI           " + Build.SUPPORTED_ABIS[0] + "\n" +
            "Processor cores   " + Runtime.getRuntime().availableProcessors() + "\n" +
            "RAM               " + ramGB() + "\n" +
            "Storage free      " + storageFree()
        ));
        root.addView(title("Performance note"));
        root.addView(cardText("This v1 build shows hardware data. A future Performance Lab can add controlled CPU/GPU/thermal benchmarks without running unsafe stress tests."));
        Button back = btn("←  Dashboard");
        back.setOnClickListener(v -> showDashboard());
        root.addView(back);
    }
}
